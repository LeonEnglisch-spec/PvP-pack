# PvP Resource Pack Manager (Phase 2)
1. JDK 21 installieren, Projekt in IntelliJ oeffnen (Gradle-Import).
2. Falls kein Wrapper vorhanden: `gradle wrapper --gradle-version 9.2.1`
3. Versionen in gradle.properties auf https://fabricmc.net/develop pruefen.
4. `./gradlew runClient` zum Testen, `./gradlew build` -> build/libs/
5. Im Spiel: Right Shift oeffnet das Fenster.
