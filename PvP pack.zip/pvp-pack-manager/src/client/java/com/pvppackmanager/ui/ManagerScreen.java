package com.pvppackmanager.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Phase-2-Huelle: dunkles Fenster, Basis fuer das GUI in Phase 3. */
public class ManagerScreen extends Screen {
    private static final int BG = 0xFF0B0B12;
    private static final int PANEL = 0xFF14141F;
    private static final int ACCENT = 0xFF7675FF;

    public ManagerScreen() {
        super(Component.literal("PvP Pack Manager"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, BG);
        int x0 = 20, y0 = 20, x1 = width - 20, y1 = height - 20;
        g.fill(x0, y0, x1, y1, PANEL);
        g.fill(x0, y0, x1, y0 + 1, ACCENT);
        g.drawString(font, "PVP PACK MANAGER", x0 + 10, y0 + 10, ACCENT);
        g.drawString(font, "Mod laeuft. GUI folgt in Phase 3. ESC zum Schliessen.",
                x0 + 10, y0 + 28, 0xFFB0B0C8);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
