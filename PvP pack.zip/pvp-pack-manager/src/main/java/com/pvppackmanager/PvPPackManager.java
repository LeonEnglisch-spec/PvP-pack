package com.pvppackmanager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Gemeinsame Konstanten. */
public final class PvPPackManager {
    public static final String MOD_ID = "pvppackmanager";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private PvPPackManager() {}
}
