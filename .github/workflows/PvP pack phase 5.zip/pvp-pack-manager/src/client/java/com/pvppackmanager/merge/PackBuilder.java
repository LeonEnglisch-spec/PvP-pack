package com.pvppackmanager.merge;

import com.pvppackmanager.PvPPackManager;
import com.pvppackmanager.data.Category;
import com.pvppackmanager.data.PackLibrary;
import com.pvppackmanager.data.ScanResult;
import com.pvppackmanager.data.Section;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Baut aus den gewaehlten Designs ein gemeinsames Resource Pack.
 * Jede Datei gehoert durch die Erkennungsregeln genau einer Kategorie; so ueberschreiben sich
 * Kategorien nicht. Bei identischen Pfaden gewinnt die Kategorie, die im Enum zuerst steht.
 */
final class PackBuilder {
    private static final String MCMETA =
            "{\"pack\":{\"min_format\":[75,0],\"max_format\":[75,0],"
                    + "\"description\":\"PvP Pack Manager - kombiniertes Pack\"}}";

    private PackBuilder() {}

    static Path resourcePackDir() {
        return FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
    }

    static Path zipPath(String signature) {
        return resourcePackDir().resolve(ResourceApplier.PREFIX + signature + ".zip");
    }

    /** @param selections Schluessel "KATEGORIE/Bereich" -> Pack-ID */
    static Path build(Map<String, String> selections, String signature) throws IOException {
        PackLibrary lib = PackLibrary.get();
        Files.createDirectories(resourcePackDir());
        Path out = zipPath(signature);
        Path tmp = resourcePackDir().resolve(out.getFileName() + ".tmp");

        Set<String> written = new HashSet<>();
        Map<String, ZipFile> open = new HashMap<>();
        int files = 0;
        int conflicts = 0;
        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(tmp))) {
            zos.putNextEntry(new ZipEntry("pack.mcmeta"));
            zos.write(MCMETA.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            for (Category c : Category.values()) {
                for (Section s : c.sections) {
                    String packId = selections.get(c.name() + "/" + s.name());
                    if (packId == null) continue;
                    Path pack = lib.packPath(packId);
                    if (pack == null) continue;
                    for (ScanResult.Entry e : lib.filesFor(packId, c, s)) {
                        String target = "assets/minecraft/textures/" + e.rel() + (e.mcmeta() ? ".mcmeta" : "");
                        if (!written.add(target)) {
                            conflicts++;
                            continue;
                        }
                        byte[] data = read(pack, open, e.name());
                        if (data == null) {
                            PvPPackManager.LOGGER.warn("Datei fehlt im Pack {}: {}", packId, e.name());
                            continue;
                        }
                        zos.putNextEntry(new ZipEntry(target));
                        zos.write(data);
                        zos.closeEntry();
                        files++;
                    }
                }
            }
        } catch (IOException | RuntimeException ex) {
            Files.deleteIfExists(tmp);
            throw ex;
        } finally {
            for (ZipFile z : open.values()) {
                try {
                    z.close();
                } catch (IOException ignored) {
                    // egal
                }
            }
        }
        Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        PvPPackManager.LOGGER.info("Kombiniertes Pack gebaut: {} Dateien, {} Pfadkonflikte", files, conflicts);
        return out;
    }

    private static byte[] read(Path pack, Map<String, ZipFile> open, String name) throws IOException {
        if (Files.isDirectory(pack)) {
            Path p = pack.resolve(name);
            return Files.exists(p) ? Files.readAllBytes(p) : null;
        }
        ZipFile z = open.get(pack.toString());
        if (z == null) {
            z = new ZipFile(pack.toFile());
            open.put(pack.toString(), z);
        }
        ZipEntry ze = z.getEntry(name);
        if (ze == null) return null;
        try (InputStream in = z.getInputStream(ze)) {
            return in.readAllBytes();
        }
    }
}
