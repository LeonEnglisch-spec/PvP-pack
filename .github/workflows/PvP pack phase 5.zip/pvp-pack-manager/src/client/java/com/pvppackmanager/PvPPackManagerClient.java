package com.pvppackmanager;

import com.mojang.blaze3d.platform.InputConstants;
import com.pvppackmanager.ui.ManagerScreen;
import com.pvppackmanager.merge.ResourceApplier;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

public class PvPPackManagerClient implements ClientModInitializer {
    private static KeyMapping openKey;
    private static boolean synced;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.pvppackmanager.open",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_RSHIFT,
                KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!synced && client.getOverlay() == null) {
                synced = true;
                ResourceApplier.syncOnStart();
            }
            while (openKey.consumeClick()) {
                Minecraft mc = Minecraft.getInstance();
                if (!(mc.screen instanceof ManagerScreen)) {
                    mc.setScreen(new ManagerScreen());
                }
            }
        });
        PvPPackManager.LOGGER.info("PvP Resource Pack Manager gestartet");
    }
}
