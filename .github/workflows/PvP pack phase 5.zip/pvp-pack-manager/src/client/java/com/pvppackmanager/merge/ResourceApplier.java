package com.pvppackmanager.merge;

import com.pvppackmanager.PvPPackManager;
import com.pvppackmanager.data.Category;
import com.pvppackmanager.data.PackLibrary;
import com.pvppackmanager.data.Section;
import com.pvppackmanager.data.Style;
import com.pvppackmanager.data.UiConfig;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.repository.PackRepository;

/**
 * Wendet die aktuelle Auswahl an: baut das kombinierte Pack (nur wenn sich die Auswahl geaendert hat),
 * aktiviert es als oberstes Pack und laedt die Ressourcen genau einmal neu.
 */
public final class ResourceApplier {
    public static final String PREFIX = "PvPManager_";

    private static volatile boolean busy;

    private ResourceApplier() {}

    /** Schluessel "KATEGORIE/Bereich" -> Pack-ID, nur fuer nicht-Vanilla-Auswahlen mit existierendem Pack. */
    static Map<String, String> activeSelections() {
        UiConfig cfg = UiConfig.get();
        PackLibrary lib = PackLibrary.get();
        Map<String, String> out = new TreeMap<>();
        for (Category c : Category.values()) {
            for (Section s : c.sections) {
                String key = c.name() + "/" + s.name();
                String id = cfg.selected(key);
                if (Style.VANILLA_ID.equals(id)) continue;
                for (Style st : lib.stylesFor(c, s)) {
                    if (st.id().equals(id)) {
                        out.put(key, id);
                        break;
                    }
                }
            }
        }
        return out;
    }

    static String signature(Map<String, String> selections) {
        if (selections.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : selections.entrySet()) {
            sb.append(e.getKey()).append('=').append(e.getValue()).append(';');
        }
        return String.format("%08x", sb.toString().hashCode());
    }

    public static boolean isPending() {
        return !signature(activeSelections()).equals(UiConfig.get().appliedSignature);
    }

    /** Beim Spielstart: sicherstellen, dass das aktive Pack zur gespeicherten Auswahl passt. */
    public static void syncOnStart() {
        try {
            Minecraft mc = Minecraft.getInstance();
            UiConfig cfg = UiConfig.get();
            String sig = signature(activeSelections());
            PackRepository repo = mc.getResourcePackRepository();
            repo.reload();
            List<String> selected = new ArrayList<>(repo.getSelectedIds());
            boolean mergedSelected = selected.stream().anyMatch(id -> id.startsWith("file/" + PREFIX));
            boolean ok = sig.isEmpty()
                    ? !mergedSelected
                    : selected.contains("file/" + PREFIX + sig + ".zip");
            cleanup(sig);
            cfg.appliedSignature = ok ? sig : "!";
            applyIfNeeded(null);
        } catch (RuntimeException e) {
            PvPPackManager.LOGGER.warn("Wiederherstellen der Auswahl fehlgeschlagen", e);
        }
    }

    /** Wendet die Auswahl an, falls sie sich seit dem letzten Mal geaendert hat. */
    public static void applyIfNeeded(Consumer<String> status) {
        UiConfig cfg = UiConfig.get();
        Map<String, String> sel = activeSelections();
        String sig = signature(sel);
        if (sig.equals(cfg.appliedSignature)) {
            if (status != null) status.accept("Alles aktuell");
            return;
        }
        if (busy) return;
        busy = true;
        Minecraft mc = Minecraft.getInstance();
        if (status != null) status.accept("Baue Pack ...");

        if (sel.isEmpty()) {
            activate(mc, null, sig, status);
            return;
        }
        Path zip = PackBuilder.zipPath(sig);
        if (Files.exists(zip)) {
            activate(mc, zip.getFileName().toString(), sig, status);
            return;
        }
        CompletableFuture.runAsync(() -> {
            try {
                Path built = PackBuilder.build(sel, sig);
                mc.execute(() -> activate(mc, built.getFileName().toString(), sig, status));
            } catch (IOException | RuntimeException e) {
                PvPPackManager.LOGGER.warn("Pack konnte nicht gebaut werden", e);
                mc.execute(() -> {
                    busy = false;
                    if (status != null) status.accept("Fehler beim Bauen: " + e.getMessage());
                });
            }
        });
    }

    /** Muss auf dem Haupt-Thread laufen. */
    private static void activate(Minecraft mc, String zipName, String sig, Consumer<String> status) {
        try {
            PackRepository repo = mc.getResourcePackRepository();
            repo.reload();
            List<String> before = new ArrayList<>(repo.getSelectedIds());
            List<String> ids = new ArrayList<>(before);
            ids.removeIf(id -> id.startsWith("file/" + PREFIX));
            if (zipName != null) {
                String newId = "file/" + zipName;
                if (!repo.getAvailableIds().contains(newId)) {
                    throw new IllegalStateException("Minecraft findet das Pack nicht: " + newId);
                }
                ids.add(newId); // letzte Position = hoechste Prioritaet
            }
            repo.setSelected(ids);
            boolean changed = !ids.equals(before);
            mc.options.updateResourcePacks(repo); // speichert und laedt neu, wenn sich die Liste geaendert hat
            if (!changed) {
                mc.reloadResourcePacks();
            }
            UiConfig cfg = UiConfig.get();
            cfg.appliedSignature = sig;
            cfg.save();
            cleanup(sig);
            if (status != null) status.accept(zipName == null ? "Zurueck auf Vanilla" : "Auswahl angewendet");
        } catch (RuntimeException e) {
            PvPPackManager.LOGGER.warn("Anwenden fehlgeschlagen", e);
            if (status != null) status.accept("Fehler beim Anwenden: " + e.getMessage());
        } finally {
            busy = false;
        }
    }

    /** Loescht alte kombinierte Packs (best effort; gesperrte Dateien werden beim naechsten Start entfernt). */
    private static void cleanup(String keepSignature) {
        String keep = keepSignature.isEmpty() ? null : PREFIX + keepSignature + ".zip";
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(PackBuilder.resourcePackDir(), PREFIX + "*")) {
            for (Path p : ds) {
                if (keep != null && p.getFileName().toString().equals(keep)) continue;
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // evtl. noch geoeffnet
                }
            }
        } catch (IOException ignored) {
            // Ordner existiert noch nicht
        }
    }
}
