package com.pvppackmanager.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pvppackmanager.PvPPackManager;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;

/** Dauerhaft gespeicherter Zustand der Oberflaeche (config/pvppackmanager.json). */
public final class UiConfig {
    public static final int DEFAULT_ACCENT = 0xFF7675FF;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static UiConfig instance;

    public int accent = DEFAULT_ACCENT;
    public String background = "tinted";
    public int opacity = 100;
    public String lastCategory = "CRYSTALS";
    /** Signatur der zuletzt angewendeten Auswahl; leer = reines Vanilla. */
    public String appliedSignature = "";
    /** Schluessel "KATEGORIE/Bereich" -> Style-ID. Fehlt ein Eintrag, gilt "vanilla". */
    public Map<String, String> selection = new HashMap<>();
    /** Schluessel "KATEGORIE/Bereich/StyleId". */
    public Set<String> favorites = new HashSet<>();

    public static UiConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvppackmanager.json");
    }

    private static UiConfig load() {
        try (Reader r = Files.newBufferedReader(file())) {
            UiConfig c = GSON.fromJson(r, UiConfig.class);
            if (c != null) {
                c.sanitize();
                return c;
            }
        } catch (NoSuchFileException ignored) {
            // erster Start
        } catch (IOException | RuntimeException e) {
            PvPPackManager.LOGGER.warn("Konfiguration konnte nicht gelesen werden, nutze Standard", e);
        }
        return new UiConfig();
    }

    private void sanitize() {
        if (selection == null) selection = new HashMap<>();
        if (favorites == null) favorites = new HashSet<>();
        if (background == null) background = "tinted";
        if (lastCategory == null) lastCategory = "CRYSTALS";
        if (appliedSignature == null) appliedSignature = "";
        opacity = Math.max(30, Math.min(100, opacity));
        accent = 0xFF000000 | accent;
    }

    public void save() {
        try {
            Files.writeString(file(), GSON.toJson(this));
        } catch (IOException e) {
            PvPPackManager.LOGGER.warn("Konfiguration konnte nicht gespeichert werden", e);
        }
    }

    public String selected(String key) {
        return selection.getOrDefault(key, "vanilla");
    }

    public void resetTheme() {
        accent = DEFAULT_ACCENT;
        background = "tinted";
        opacity = 100;
        save();
    }
}
