package com.pvppackmanager.data;

import net.minecraft.world.item.Item;

/** Unterbereich einer Kategorie (z. B. "Pickaxes" in "Tools"). */
public record Section(String name, Item icon) {}
