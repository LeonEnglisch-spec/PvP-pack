package com.pvppackmanager.data;

/** Ein auswaehlbares Design. "vanilla" ist immer vorhanden, alles andere kommt aus importierten Packs. */
public record Style(String id, String name, int files) {
    public static final String VANILLA_ID = "vanilla";

    public boolean isVanilla() {
        return VANILLA_ID.equals(id);
    }
}
