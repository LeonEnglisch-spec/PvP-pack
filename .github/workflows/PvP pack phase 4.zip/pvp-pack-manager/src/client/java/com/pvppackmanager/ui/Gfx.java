package com.pvppackmanager.ui;

import net.minecraft.client.gui.GuiGraphics;

/** Kleine Zeichenhelfer: Farben mischen und abgerundete Rechtecke. */
public final class Gfx {
    private Gfx() {}

    public static int alpha(int argb, float a) {
        int al = Math.max(0, Math.min(255, Math.round((argb >>> 24) * a)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = Math.round(ar + (br - ar) * t);
        int g = Math.round(ag + (bg - ag) * t);
        int bl = Math.round(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static void fillRound(GuiGraphics g, int x0, int y0, int x1, int y1, int r, int color) {
        if (r <= 0 || x1 - x0 < 2 * r || y1 - y0 < 2 * r) {
            g.fill(x0, y0, x1, y1, color);
            return;
        }
        g.fill(x0, y0 + r, x1, y1 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            g.fill(x0 + inset, y0 + i, x1 - inset, y0 + i + 1, color);
            g.fill(x0 + inset, y1 - i - 1, x1 - inset, y1 - i, color);
        }
    }

    public static void roundBorder(GuiGraphics g, int x0, int y0, int x1, int y1, int r, int border, int fill) {
        fillRound(g, x0, y0, x1, y1, r, border);
        fillRound(g, x0 + 1, y0 + 1, x1 - 1, y1 - 1, Math.max(0, r - 1), fill);
    }
}
