package com.pvppackmanager.data;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Ordnet Texturpfade (relativ zu assets/minecraft/textures/) einer Kategorie und einem Bereich zu. */
public final class Detector {
    public record Match(Category category, String section) {}

    private record Rule(Pattern pattern, Category category, String section) {}

    private static final String MAT = "(?:wooden|stone|iron|golden|diamond|netherite|copper)";
    private static final List<Rule> RULES = new ArrayList<>();

    private static void add(String regex, Category c, String section) {
        RULES.add(new Rule(Pattern.compile(regex), c, section));
    }

    static {
        add("^(?:entity/end_crystal/.+|item/end_crystal)\\.png$", Category.CRYSTALS, "Crystals");

        add("^item/" + MAT + "_sword\\.png$", Category.SWORDS, "Swords");

        add("^item/" + MAT + "_pickaxe\\.png$", Category.TOOLS, "Pickaxes");
        add("^item/" + MAT + "_axe\\.png$", Category.TOOLS, "Axes");
        add("^item/" + MAT + "_shovel\\.png$", Category.TOOLS, "Shovels");
        add("^item/" + MAT + "_hoe\\.png$", Category.TOOLS, "Hoes");

        add("^item/\\w+_helmet\\.png$", Category.ARMOR, "Helmets");
        add("^item/\\w+_chestplate\\.png$", Category.ARMOR, "Chestplates");
        add("^item/\\w+_leggings\\.png$", Category.ARMOR, "Leggings");
        add("^item/\\w+_boots\\.png$", Category.ARMOR, "Boots");
        add("^entity/equipment/humanoid_leggings/.+\\.png$", Category.ARMOR, "Leggings");
        add("^entity/equipment/humanoid/.+\\.png$", Category.ARMOR, "Chestplates");
        add("^models/armor/.+_layer_2\\.png$", Category.ARMOR, "Leggings");
        add("^models/armor/.+_layer_1\\.png$", Category.ARMOR, "Chestplates");

        add("^block/grass_block(?:_\\w+)?\\.png$", Category.BLOCKS, "Grass");
        add("^block/(?:stone|cobblestone|stone_bricks|deepslate|andesite|diorite|granite)\\.png$",
                Category.BLOCKS, "Stone");
        add("^block/(?:dirt|coarse_dirt|podzol|mycelium)\\.png$", Category.BLOCKS, "Dirt");
        add("^block/\\w+_planks\\.png$", Category.BLOCKS, "Planks");
        add("^block/(?:crying_)?obsidian\\.png$", Category.BLOCKS, "Obsidian");

        add("^block/(?:deepslate_)?diamond_ore\\.png$", Category.ORES, "Diamond");
        add("^block/(?:deepslate_)?iron_ore\\.png$", Category.ORES, "Iron");
        add("^block/(?:deepslate_)?gold_ore\\.png$", Category.ORES, "Gold");
        add("^block/ancient_debris_\\w+\\.png$", Category.ORES, "Netherite");

        add("^environment/.+\\.png$", Category.SKY, "Sky");
        add("^particle/.+\\.png$", Category.PARTICLES, "Particles");
        add("^item/totem_of_undying\\.png$", Category.TOTEMS, "Totems");

        add("^item/(?:golden_apple|apple|enchanted_golden_apple)\\.png$", Category.FOOD, "Golden Apple");
        add("^item/(?:cooked_beef|cooked_porkchop|bread)\\.png$", Category.FOOD, "Cooked Beef");

        add("^gui/sprites/hud/crosshair.*\\.png$", Category.CROSSHAIRS, "Crosshairs");
        add("^gui/.+\\.png$", Category.GUI, "Hotbar");

        add("^(?:item/arrow|entity/projectiles/arrow|entity/projectiles/spectral_arrow)\\.png$",
                Category.PROJECTILES, "Arrows");
        add("^item/ender_pearl\\.png$", Category.PROJECTILES, "Pearls");
        add("^item/snowball\\.png$", Category.PROJECTILES, "Snowballs");
    }

    private Detector() {}

    /** @param rel kleingeschriebener Pfad ohne ".mcmeta"; null, wenn keine Regel passt. */
    public static Match detect(String rel) {
        for (Rule r : RULES) {
            if (r.pattern().matcher(rel).matches()) {
                return new Match(r.category(), r.section());
            }
        }
        return null;
    }
}
