package com.pvppackmanager.data;

import java.util.List;

/** Liefert die Designs je Kategorie und Bereich: Vanilla plus alle importierten Packs. */
public final class StyleLibrary {
    public static final Style VANILLA = new Style(Style.VANILLA_ID, "Vanilla", 0);

    private StyleLibrary() {}

    public static List<Style> styles(Category category, Section section) {
        return PackLibrary.get().stylesFor(category, section);
    }

    public static int count(Category category) {
        int n = 0;
        for (Section s : category.sections) {
            n += styles(category, s).size();
        }
        return n;
    }
}
