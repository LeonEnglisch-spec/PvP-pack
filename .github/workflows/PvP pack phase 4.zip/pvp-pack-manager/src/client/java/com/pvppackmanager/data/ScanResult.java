package com.pvppackmanager.data;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Ergebnis der Analyse eines Resource Packs. */
public final class ScanResult {
    /** Eine Datei im Pack. {@code category == null} bedeutet: nicht automatisch erkannt. */
    public record Entry(String name, String rel, boolean mcmeta, Category category, String section) {}

    public final List<Entry> entries;
    private final Map<Category, Integer> perCategory = new EnumMap<>(Category.class);
    private int unrecognized;
    private int textures;

    public ScanResult(List<Entry> entries) {
        this.entries = entries;
        for (Entry e : entries) {
            if (e.mcmeta()) continue;
            textures++;
            if (e.category() == null) {
                unrecognized++;
            } else {
                perCategory.merge(e.category(), 1, Integer::sum);
            }
        }
    }

    public int textures() {
        return textures;
    }

    public int unrecognized() {
        return unrecognized;
    }

    public int count(Category c) {
        return perCategory.getOrDefault(c, 0);
    }
}
