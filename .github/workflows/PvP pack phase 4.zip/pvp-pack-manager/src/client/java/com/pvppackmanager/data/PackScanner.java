package com.pvppackmanager.data;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Liest die Dateiliste eines Packs (ZIP oder Ordner) und erkennt die Kategorien. */
public final class PackScanner {
    private static final String MARKER = "assets/minecraft/textures/";

    private PackScanner() {}

    public static ScanResult scan(Path pack) throws IOException {
        List<String> names = Files.isDirectory(pack) ? listDir(pack) : listZip(pack);
        List<ScanResult.Entry> out = new ArrayList<>();
        for (String raw : names) {
            String name = raw.replace('\\', '/');
            String lower = name.toLowerCase(Locale.ROOT);
            int i = lower.indexOf(MARKER);
            if (i < 0 || (i > 0 && lower.charAt(i - 1) != '/')) continue;
            String rel = lower.substring(i + MARKER.length());
            boolean mcmeta = rel.endsWith(".mcmeta");
            String base = mcmeta ? rel.substring(0, rel.length() - ".mcmeta".length()) : rel;
            if (!base.endsWith(".png")) continue;
            Detector.Match m = Detector.detect(base);
            out.add(new ScanResult.Entry(name, base, mcmeta,
                    m == null ? null : m.category(), m == null ? null : m.section()));
        }
        return new ScanResult(out);
    }

    private static List<String> listZip(Path zip) throws IOException {
        List<String> out = new ArrayList<>();
        try (ZipFile z = new ZipFile(zip.toFile())) {
            z.stream().filter(e -> !e.isDirectory()).map(ZipEntry::getName).forEach(out::add);
        }
        return out;
    }

    private static List<String> listDir(Path dir) throws IOException {
        try (Stream<Path> s = Files.walk(dir)) {
            return s.filter(Files::isRegularFile)
                    .map(p -> dir.relativize(p).toString().replace('\\', '/'))
                    .toList();
        }
    }
}
