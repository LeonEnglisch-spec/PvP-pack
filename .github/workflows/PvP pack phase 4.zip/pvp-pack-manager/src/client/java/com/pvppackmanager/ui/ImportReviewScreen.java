package com.pvppackmanager.ui;

import com.pvppackmanager.data.Category;
import com.pvppackmanager.data.PackLibrary;
import com.pvppackmanager.data.ScanResult;
import com.pvppackmanager.data.UiConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Zeigt, was in einem Pack erkannt wurde, und laesst nicht erkannte Texturen einer Kategorie zuordnen. */
public class ImportReviewScreen extends Screen {
    private static final int TEXT = 0xFFE8E8F4;
    private static final int DIM = 0xFF8A8AA3;
    private static final int FAINT = 0xFF55556B;
    private static final int GREEN = 0xFF4ADE80;

    private record Hit(int x0, int y0, int x1, int y1, Runnable action) {
        boolean contains(double x, double y) {
            return x >= x0 && x < x1 && y >= y0 && y < y1;
        }
    }

    private final ManagerScreen parent;
    private final PackLibrary.Staged staged;
    private final UiConfig cfg = UiConfig.get();
    private final List<Hit> hits = new ArrayList<>();
    /** 0 = nicht importieren, 1..n = Kategorie (Reihenfolge wie im Enum). */
    private int choice = 0;
    private boolean finished;

    public ImportReviewScreen(ManagerScreen parent, PackLibrary.Staged staged) {
        super(Component.literal("Import"));
        this.parent = parent;
        this.staged = staged;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        // bewusst leer
    }

    private void confirm() {
        if (finished) return;
        finished = true;
        Category target = choice == 0 ? null : Category.values()[choice - 1];
        PackLibrary.get().commit(staged, target);
        parent.setStatus("Importiert: " + staged.meta().name);
        parent.reviewFinished();
    }

    private void cancel() {
        if (finished) return;
        finished = true;
        PackLibrary.get().discard(staged);
        parent.setStatus("Import abgebrochen");
        parent.reviewFinished();
    }

    @Override
    public void onClose() {
        cancel();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        hits.clear();
        int accent = cfg.accent;
        int bg = Theme.background(cfg);
        ScanResult scan = staged.scan();

        List<Category> found = new ArrayList<>();
        for (Category c : Category.values()) {
            if (scan.count(c) > 0) found.add(c);
        }

        int w = 300;
        int rows = found.size();
        int h = 78 + rows * 12 + (scan.unrecognized() > 0 ? 44 : 10) + 30;
        int x = (width - w) / 2;
        int y = Math.max(8, (height - h) / 2);

        g.fill(0, 0, width, height, 0xCC000000);
        Gfx.roundBorder(g, x, y, x + w, y + h, 6, Gfx.mix(bg, accent, 0.5f), Gfx.mix(bg, 0xFF000000, 0.2f));

        g.drawString(font, "PACK IMPORTIEREN", x + 12, y + 10, accent);
        String name = font.plainSubstrByWidth(staged.meta().name, w - 24);
        g.drawString(font, name, x + 12, y + 24, TEXT);
        g.drawString(font, scan.textures() + " Texturen, " + (scan.textures() - scan.unrecognized())
                + " automatisch erkannt", x + 12, y + 36, DIM);
        g.fill(x + 12, y + 50, x + w - 12, y + 51, Gfx.alpha(0xFFFFFFFF, 0.08f));

        int cy = y + 58;
        for (Category c : found) {
            g.drawString(font, c.title, x + 14, cy, TEXT);
            String n = String.valueOf(scan.count(c));
            g.drawString(font, n, x + w - 14 - font.width(n), cy, GREEN);
            cy += 12;
        }
        if (found.isEmpty()) {
            g.drawString(font, "Nichts automatisch erkannt", x + 14, cy, DIM);
            cy += 12;
        }

        if (scan.unrecognized() > 0) {
            cy += 6;
            g.drawString(font, "Nicht erkannt: " + scan.unrecognized(), x + 14, cy, TEXT);
            cy += 13;
            String label = choice == 0 ? "Nicht importieren" : Category.values()[choice - 1].title;
            String btn = "Zuordnen zu: " + label;
            int bw = font.width(btn) + 16;
            boolean hov = mx >= x + 14 && mx < x + 14 + bw && my >= cy && my < cy + 14;
            Gfx.roundBorder(g, x + 14, cy, x + 14 + bw, cy + 14, 3, hov ? accent : 0xFF24243A, 0xFF0E0E16);
            g.drawString(font, btn, x + 22, cy + 3, hov ? TEXT : DIM);
            hits.add(new Hit(x + 14, cy, x + 14 + bw, cy + 14,
                    () -> choice = (choice + 1) % (Category.values().length + 1)));
            cy += 16;
        }

        int by = y + h - 24;
        int okW = 80;
        int noW = 70;
        boolean okHov = mx >= x + w - 12 - okW && mx < x + w - 12 && my >= by && my < by + 14;
        boolean noHov = mx >= x + w - 20 - okW - noW && mx < x + w - 20 - okW && my >= by && my < by + 14;
        Gfx.roundBorder(g, x + w - 12 - okW, by, x + w - 12, by + 14, 3, accent,
                okHov ? Gfx.mix(0xFF0E0E16, accent, 0.35f) : Gfx.mix(0xFF0E0E16, accent, 0.18f));
        g.drawString(font, "IMPORTIEREN", x + w - 12 - okW + (okW - font.width("IMPORTIEREN")) / 2, by + 3, TEXT);
        hits.add(new Hit(x + w - 12 - okW, by, x + w - 12, by + 14, this::confirm));
        Gfx.roundBorder(g, x + w - 20 - okW - noW, by, x + w - 20 - okW, by + 14, 3,
                noHov ? accent : 0xFF24243A, 0xFF0E0E16);
        g.drawString(font, "ABBRECHEN", x + w - 20 - okW - noW + (noW - font.width("ABBRECHEN")) / 2, by + 3,
                noHov ? TEXT : DIM);
        hits.add(new Hit(x + w - 20 - okW - noW, by, x + w - 20 - okW, by + 14, this::cancel));

        g.drawString(font, "Eine Kopie wird in pvp-pack-manager/packs abgelegt.", x + 12, y + h - 38 + 0, FAINT);

        super.render(g, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit hit = hits.get(i);
                if (hit.contains(event.x(), event.y())) {
                    hit.action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }
}
