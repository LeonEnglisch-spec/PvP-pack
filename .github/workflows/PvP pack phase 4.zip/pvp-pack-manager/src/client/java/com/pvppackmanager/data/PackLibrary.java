package com.pvppackmanager.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pvppackmanager.PvPPackManager;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Verwaltet importierte Packs unter {@code <gameDir>/pvp-pack-manager/packs/}.
 * Importierte Packs werden dorthin kopiert, das Original bleibt unveraendert.
 */
public final class PackLibrary {
    /** Gespeicherte Angaben zu einem Pack. */
    public static final class Meta {
        public String id;
        public String name;
        public String file;
        public boolean dir;
        /** Kategorie (Enum-Name) fuer nicht erkannte Texturen, oder null. */
        public String unassigned;
    }

    private static final class Index {
        List<Meta> packs = new ArrayList<>();
    }

    private record Loaded(Meta meta, ScanResult scan, Map<String, Integer> counts) {}

    /** Ein kopiertes, analysiertes, aber noch nicht bestaetigtes Pack. */
    public record Staged(Meta meta, ScanResult scan, Path path) {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static PackLibrary instance;

    private final List<Loaded> loaded = new ArrayList<>();

    public static PackLibrary get() {
        if (instance == null) {
            instance = new PackLibrary();
            instance.load();
        }
        return instance;
    }

    public static Path packsDir() {
        return FabricLoader.getInstance().getGameDir().resolve("pvp-pack-manager").resolve("packs");
    }

    private static Path indexFile() {
        return packsDir().resolve("index.json");
    }

    // ------------------------------------------------------------------- laden

    private void load() {
        Index index = new Index();
        try (Reader r = Files.newBufferedReader(indexFile())) {
            Index read = GSON.fromJson(r, Index.class);
            if (read != null && read.packs != null) index = read;
        } catch (NoSuchFileException ignored) {
            // noch nichts importiert
        } catch (IOException | RuntimeException e) {
            PvPPackManager.LOGGER.warn("Pack-Index konnte nicht gelesen werden", e);
        }
        for (Meta m : index.packs) {
            try {
                ScanResult scan = PackScanner.scan(packsDir().resolve(m.file));
                loaded.add(new Loaded(m, scan, buildCounts(m, scan)));
            } catch (IOException | RuntimeException e) {
                PvPPackManager.LOGGER.warn("Pack {} konnte nicht geladen werden", m.name, e);
            }
        }
    }

    private void saveIndex() {
        Index index = new Index();
        for (Loaded l : loaded) index.packs.add(l.meta());
        try {
            Files.createDirectories(packsDir());
            Files.writeString(indexFile(), GSON.toJson(index));
        } catch (IOException e) {
            PvPPackManager.LOGGER.warn("Pack-Index konnte nicht gespeichert werden", e);
        }
    }

    private static Map<String, Integer> buildCounts(Meta meta, ScanResult scan) {
        Map<String, Integer> counts = new HashMap<>();
        Category fallback = null;
        if (meta.unassigned != null) {
            try {
                fallback = Category.valueOf(meta.unassigned);
            } catch (IllegalArgumentException ignored) {
                // ungueltiger Wert: ignorieren
            }
        }
        for (ScanResult.Entry e : scan.entries) {
            if (e.mcmeta()) continue;
            Category c = e.category();
            String section = e.section();
            if (c == null) {
                if (fallback == null) continue;
                c = fallback;
                section = fallback.sections.get(0).name();
            }
            counts.merge(c.name() + "/" + section, 1, Integer::sum);
        }
        return counts;
    }

    // ---------------------------------------------------------------- Abfragen

    public List<Style> stylesFor(Category category, Section section) {
        List<Style> out = new ArrayList<>();
        out.add(StyleLibrary.VANILLA);
        String key = category.name() + "/" + section.name();
        for (Loaded l : loaded) {
            int n = l.counts().getOrDefault(key, 0);
            if (n > 0) out.add(new Style(l.meta().id, l.meta().name, n));
        }
        return out;
    }

    public int packCount() {
        return loaded.size();
    }

    // ----------------------------------------------------------------- Import

    /** Kopiert ein Pack in den Pack-Ordner und analysiert es. Darf auf einem Hintergrund-Thread laufen. */
    public Staged stage(Path source) throws IOException {
        boolean dir = Files.isDirectory(source);
        String fileName = source.getFileName().toString();
        if (!dir && !fileName.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            throw new IOException("Nur ZIP-Dateien oder Ordner werden unterstuetzt");
        }
        String stem = dir ? fileName : fileName.substring(0, fileName.length() - 4);
        String id = uniqueId(stem.replaceAll("[^A-Za-z0-9._-]", "_"));
        String target = dir ? id : id + ".zip";

        Files.createDirectories(packsDir());
        Path dest = packsDir().resolve(target);
        if (dir) {
            copyTree(source, dest);
        } else {
            Files.copy(source, dest);
        }

        ScanResult scan;
        try {
            scan = PackScanner.scan(dest);
        } catch (IOException | RuntimeException e) {
            deleteTree(dest);
            throw new IOException("Pack konnte nicht gelesen werden: " + e.getMessage(), e);
        }
        if (scan.textures() == 0) {
            deleteTree(dest);
            throw new IOException("Keine Texturen unter assets/minecraft/textures gefunden");
        }
        Meta meta = new Meta();
        meta.id = id;
        meta.name = stem;
        meta.file = target;
        meta.dir = dir;
        return new Staged(meta, scan, dest);
    }

    /** Uebernimmt ein bestaetigtes Pack. {@code unassignedTo} kann null sein. */
    public void commit(Staged staged, Category unassignedTo) {
        staged.meta().unassigned = unassignedTo == null ? null : unassignedTo.name();
        loaded.add(new Loaded(staged.meta(), staged.scan(), buildCounts(staged.meta(), staged.scan())));
        saveIndex();
    }

    public void discard(Staged staged) {
        deleteTree(staged.path());
    }

    private String uniqueId(String base) {
        if (base.isEmpty()) base = "pack";
        String id = base;
        int n = 2;
        while (idTaken(id)) {
            id = base + "-" + n++;
        }
        return id;
    }

    private boolean idTaken(String id) {
        for (Loaded l : loaded) {
            if (l.meta().id.equals(id)) return true;
        }
        return Files.exists(packsDir().resolve(id)) || Files.exists(packsDir().resolve(id + ".zip"));
    }

    private static void copyTree(Path from, Path to) throws IOException {
        try (Stream<Path> s = Files.walk(from)) {
            for (Path p : (Iterable<Path>) s::iterator) {
                Path target = to.resolve(from.relativize(p).toString());
                if (Files.isDirectory(p)) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    Files.copy(p, target);
                }
            }
        }
    }

    private static void deleteTree(Path p) {
        try {
            if (!Files.exists(p)) return;
            if (Files.isDirectory(p)) {
                try (Stream<Path> s = Files.walk(p)) {
                    for (Path q : (Iterable<Path>) s.sorted(java.util.Comparator.reverseOrder())::iterator) {
                        Files.deleteIfExists(q);
                    }
                }
            } else {
                Files.deleteIfExists(p);
            }
        } catch (IOException e) {
            PvPPackManager.LOGGER.warn("Konnte {} nicht loeschen", p, e);
        }
    }
}
