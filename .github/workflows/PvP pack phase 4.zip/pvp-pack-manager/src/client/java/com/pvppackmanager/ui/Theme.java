package com.pvppackmanager.ui;

import com.pvppackmanager.data.UiConfig;

public final class Theme {
    public record Preset(String name, int color) {}

    public static final Preset[] PRESETS = {
            new Preset("Ice", 0xFF4DD6E8),
            new Preset("Crimson", 0xFFFF4D6A),
            new Preset("Amethyst", 0xFFA574FF),
            new Preset("Amber", 0xFFFFB02E),
            new Preset("Sakura", 0xFFFF8FCB),
            new Preset("Mono", 0xFFFFFFFF),
    };

    public static final String[] BACKGROUNDS = {"navy", "tinted", "black"};

    private Theme() {}

    public static int background(UiConfig cfg) {
        return switch (cfg.background) {
            case "navy" -> 0xFF0A0F1F;
            case "black" -> 0xFF030304;
            default -> Gfx.mix(0xFF0A0A10, cfg.accent, 0.07f);
        };
    }
}
