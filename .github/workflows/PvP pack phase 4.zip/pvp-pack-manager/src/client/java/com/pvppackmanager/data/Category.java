package com.pvppackmanager.data;

import java.util.List;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public enum Category {
    CRYSTALS("Crystals", Items.END_CRYSTAL,
            new Section("Crystals", Items.END_CRYSTAL)),
    SWORDS("Swords", Items.DIAMOND_SWORD,
            new Section("Swords", Items.DIAMOND_SWORD)),
    TOOLS("Tools", Items.DIAMOND_PICKAXE,
            new Section("Pickaxes", Items.DIAMOND_PICKAXE),
            new Section("Axes", Items.DIAMOND_AXE),
            new Section("Shovels", Items.DIAMOND_SHOVEL),
            new Section("Hoes", Items.DIAMOND_HOE)),
    ARMOR("Armor", Items.DIAMOND_CHESTPLATE,
            new Section("Helmets", Items.DIAMOND_HELMET),
            new Section("Chestplates", Items.DIAMOND_CHESTPLATE),
            new Section("Leggings", Items.DIAMOND_LEGGINGS),
            new Section("Boots", Items.DIAMOND_BOOTS)),
    BLOCKS("Blocks", Items.GRASS_BLOCK,
            new Section("Grass", Items.GRASS_BLOCK),
            new Section("Stone", Items.STONE),
            new Section("Dirt", Items.DIRT),
            new Section("Planks", Items.OAK_PLANKS),
            new Section("Obsidian", Items.OBSIDIAN)),
    ORES("Ores", Items.DIAMOND_ORE,
            new Section("Diamond", Items.DIAMOND_ORE),
            new Section("Iron", Items.IRON_ORE),
            new Section("Gold", Items.GOLD_ORE),
            new Section("Netherite", Items.ANCIENT_DEBRIS)),
    SKY("Sky", Items.CLOCK,
            new Section("Sky", Items.CLOCK)),
    PARTICLES("Particles", Items.BLAZE_POWDER,
            new Section("Particles", Items.BLAZE_POWDER)),
    TOTEMS("Totems", Items.TOTEM_OF_UNDYING,
            new Section("Totems", Items.TOTEM_OF_UNDYING)),
    FOOD("Food", Items.GOLDEN_APPLE,
            new Section("Golden Apple", Items.GOLDEN_APPLE),
            new Section("Cooked Beef", Items.COOKED_BEEF)),
    GUI("GUI", Items.ITEM_FRAME,
            new Section("Hotbar", Items.ITEM_FRAME)),
    CROSSHAIRS("Crosshairs", Items.SPYGLASS,
            new Section("Crosshairs", Items.SPYGLASS)),
    PROJECTILES("Projectiles", Items.ARROW,
            new Section("Arrows", Items.ARROW),
            new Section("Pearls", Items.ENDER_PEARL),
            new Section("Snowballs", Items.SNOWBALL)),
    ANIMATIONS("Animations", Items.NETHER_STAR,
            new Section("Animations", Items.NETHER_STAR)),
    OTHER("Other", Items.CHEST,
            new Section("Other", Items.CHEST));

    public final String title;
    public final Item icon;
    public final List<Section> sections;

    Category(String title, Item icon, Section... sections) {
        this.title = title;
        this.icon = icon;
        this.sections = List.of(sections);
    }
}
