package com.pvppackmanager.data;

/** Ein auswaehlbares Design. "vanilla" ist immer vorhanden. */
public record Style(String id, String name) {}
