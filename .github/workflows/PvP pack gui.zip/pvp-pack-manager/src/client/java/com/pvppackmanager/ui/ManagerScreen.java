package com.pvppackmanager.ui;

import com.mojang.blaze3d.platform.InputConstants;
import com.pvppackmanager.data.Category;
import com.pvppackmanager.data.Section;
import com.pvppackmanager.data.Style;
import com.pvppackmanager.data.StyleLibrary;
import com.pvppackmanager.data.UiConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Hauptoberflaeche: Sidebar, Karten-Raster, Themes-Panel, Fussleiste. */
public class ManagerScreen extends Screen {
    private static final int TEXT = 0xFFE8E8F4;
    private static final int DIM = 0xFF8A8AA3;
    private static final int FAINT = 0xFF55556B;
    private static final int GREEN = 0xFF4ADE80;
    private static final int GOLD = 0xFFFFC83D;
    private static final int CW = 74;
    private static final int CH = 88;
    private static final int GAP = 8;
    private static final int ROW_H = 17;

    private static final Map<Item, ItemStack> STACKS = new HashMap<>();

    private record Hit(int x0, int y0, int x1, int y1, Runnable left, Runnable right) {
        boolean contains(double x, double y) {
            return x >= x0 && x < x1 && y >= y0 && y < y1;
        }
    }

    private record Block(Section section, List<Style> styles) {}

    private record Zoom(Item icon, String title, String subtitle) {}

    private final UiConfig cfg = UiConfig.get();
    private Category category;
    private boolean favoritesOnly;
    private String query = "";
    private EditBox search;
    private int ticks;
    private float open;
    private float scroll, scrollTarget, sideScroll, sideScrollTarget;
    private float contentHeight, sideContentHeight;
    private boolean draggingOpacity;
    private int sliderX0, sliderX1, sliderY0, sliderY1;
    private final Map<String, Float> anim = new HashMap<>();
    private final List<Hit> hits = new ArrayList<>();
    private Zoom zoom;
    private String hoveredFavKey;
    private String tooltip;
    private int tipX, tipY;

    // Layout
    private int wx0, wy0, wx1, wy1, topY, botY, panelW;
    private int sx0, sy0, sx1, sy1;
    private int gx0, gy0, gx1, gy1;
    private int mx0, mx1;

    public ManagerScreen() {
        super(Component.literal("PvP Pack Manager"));
        try {
            category = Category.valueOf(cfg.lastCategory);
        } catch (IllegalArgumentException e) {
            category = Category.CRYSTALS;
        }
    }

    @Override
    protected void init() {
        wx0 = 10;
        wy0 = 10;
        wx1 = width - 10;
        wy1 = height - 10;
        int headerH = 30;
        int footerH = 22;
        int sideW = 120;
        panelW = (wx1 - wx0) >= 560 ? 132 : 0;
        topY = wy0 + headerH;
        botY = wy1 - footerH;
        sx0 = wx0 + 6;
        sx1 = wx0 + sideW;
        sy0 = topY + 22;
        sy1 = botY - 4;
        mx0 = wx0 + sideW + 10;
        mx1 = wx1 - panelW - (panelW > 0 ? 12 : 8);
        gx0 = mx0;
        gx1 = mx1;
        gy0 = topY + 38;
        gy1 = botY - 4;

        search = new EditBox(font, mx1 - 150, topY + 6, 90, 12, Component.literal("Search"));
        search.setBordered(false);
        search.setHint(Component.literal("Search..."));
        search.setMaxLength(32);
        search.setValue(query);
        search.setResponder(s -> {
            query = s.toLowerCase(Locale.ROOT).trim();
            scrollTarget = 0;
        });
        addRenderableWidget(search);
    }

    @Override
    public void tick() {
        ticks++;
    }

    @Override
    public void removed() {
        cfg.lastCategory = category.name();
        cfg.save();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        // bewusst leer: das Fenster zeichnet seinen eigenen Hintergrund
    }

    // ------------------------------------------------------------------ helpers

    private float anim(String key, boolean on) {
        float v = anim.getOrDefault(key, 0f);
        v += ((on ? 1f : 0f) - v) * 0.3f;
        anim.put(key, v);
        return v;
    }

    private void icon(GuiGraphics g, Item item, float x, float y, float scale) {
        ItemStack stack = STACKS.computeIfAbsent(item, ItemStack::new);
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.renderItem(stack, 0, 0);
        g.pose().popMatrix();
    }

    private void text(GuiGraphics g, String s, float x, float y, float scale, int color) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.drawString(font, s, 0, 0, color);
        g.pose().popMatrix();
    }

    private boolean in(double mx, double my, int x0, int y0, int x1, int y1) {
        return mx >= x0 && mx < x1 && my >= y0 && my < y1;
    }

    private String key(Section s) {
        return category.name() + "/" + s.name();
    }

    private String favKey(Section s, Style st) {
        return key(s) + "/" + st.id();
    }

    private void selectCategory(Category c) {
        category = c;
        scroll = 0;
        scrollTarget = 0;
    }

    private List<Block> filtered() {
        List<Block> out = new ArrayList<>();
        for (Section s : category.sections) {
            List<Style> list = new ArrayList<>();
            for (Style st : StyleLibrary.styles(category, s)) {
                if (favoritesOnly && !cfg.favorites.contains(favKey(s, st))) continue;
                if (!query.isEmpty()
                        && !st.name().toLowerCase(Locale.ROOT).contains(query)
                        && !s.name().toLowerCase(Locale.ROOT).contains(query)) continue;
                list.add(st);
            }
            if (!list.isEmpty()) out.add(new Block(s, list));
        }
        return out;
    }

    private void toggleFavorite(String favKey) {
        if (!cfg.favorites.remove(favKey)) {
            cfg.favorites.add(favKey);
        }
        cfg.save();
    }

    private void updateOpacity(double mouseX) {
        float t = (float) ((mouseX - sliderX0) / (double) (sliderX1 - sliderX0));
        t = Math.max(0f, Math.min(1f, t));
        cfg.opacity = 30 + Math.round(t * 70f);
    }

    // ------------------------------------------------------------------- render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        hits.clear();
        hoveredFavKey = null;
        tooltip = null;
        open += (1f - open) * 0.25f;
        scroll += (scrollTarget - scroll) * 0.3f;
        sideScroll += (sideScrollTarget - sideScroll) * 0.3f;

        int accent = cfg.accent;
        int bg = Theme.background(cfg);
        float op = cfg.opacity / 100f;

        g.fill(0, 0, width, height, Gfx.alpha(0xFF000000, 0.55f * open * Math.max(op, 0.4f)));
        Gfx.roundBorder(g, wx0, wy0, wx1, wy1, 6,
                Gfx.alpha(Gfx.mix(bg, accent, 0.28f), open),
                Gfx.alpha(bg, op * open));

        drawHeader(g, mouseX, mouseY, accent);
        drawSidebar(g, mouseX, mouseY, accent, bg);
        drawMain(g, mouseX, mouseY, accent);
        if (panelW > 0) {
            drawPanel(g, mouseX, mouseY, accent, bg);
        }
        drawFooter(g, mouseX, mouseY, accent);

        super.render(g, mouseX, mouseY, delta);

        if (zoom != null) {
            drawZoom(g, accent);
        } else if (tooltip != null) {
            int w = font.width(tooltip) + 10;
            int x = Math.min(tipX + 8, width - w - 4);
            int y = tipY + 12;
            Gfx.roundBorder(g, x, y, x + w, y + 15, 3, 0xFF2A2A44, 0xFF0E0E16);
            g.drawString(font, tooltip, x + 5, y + 4, TEXT);
        }
    }

    private void drawHeader(GuiGraphics g, int mx, int my, int accent) {
        Gfx.fillRound(g, wx0 + 10, wy0 + 9, wx0 + 21, wy0 + 20, 3, accent);
        g.drawString(font, "PVP PACK", wx0 + 28, wy0 + 7, TEXT);
        g.drawString(font, "STYLE LIBRARY", wx0 + 28, wy0 + 17, DIM);

        if (wx1 - wx0 < 560) return;
        Category[] all = Category.values();
        int x = wx1 - 10 - all.length * 18;
        for (Category c : all) {
            boolean act = c == category;
            boolean hov = in(mx, my, x, wy0 + 4, x + 18, wy0 + 26);
            float h = anim("hd/" + c.name(), hov);
            if (act || h > 0.02f) {
                Gfx.fillRound(g, x + 1, wy0 + 5, x + 17, wy0 + 23, 3,
                        Gfx.alpha(act ? accent : 0xFFFFFFFF, act ? 0.18f : 0.07f * h));
            }
            icon(g, c.icon, x + 2.5f, wy0 + 7.5f, 0.8f);
            if (act) g.fill(x + 3, wy0 + 24, x + 15, wy0 + 26, accent);
            if (hov) {
                tooltip = c.title;
                tipX = mx;
                tipY = my;
            }
            final Category target = c;
            hits.add(new Hit(x, wy0 + 4, x + 18, wy0 + 26, () -> selectCategory(target), null));
            x += 18;
        }
    }

    private void drawSidebar(GuiGraphics g, int mx, int my, int accent, int bg) {
        g.drawString(font, "COLLECTIONS", sx0 + 4, topY + 6, accent);
        g.fill(sx0 + 4, topY + 17, sx0 + 4 + font.width("COLLECTIONS"), topY + 18, accent);

        Category[] all = Category.values();
        sideContentHeight = all.length * ROW_H;
        float maxScroll = Math.max(0, sideContentHeight - (sy1 - sy0));
        sideScrollTarget = Math.max(0, Math.min(maxScroll, sideScrollTarget));

        g.enableScissor(sx0, sy0, sx1, sy1);
        int i = 0;
        for (Category c : all) {
            int ry = Math.round(sy0 - sideScroll + i * ROW_H);
            i++;
            if (ry + ROW_H < sy0 || ry > sy1) continue;
            boolean act = c == category;
            boolean hov = in(mx, my, sx0, Math.max(ry, sy0), sx1, Math.min(ry + ROW_H, sy1));
            float h = anim("sd/" + c.name(), hov);
            if (act) {
                Gfx.fillRound(g, sx0, ry, sx1, ry + ROW_H - 1, 3, Gfx.alpha(accent, 0.16f));
                g.fill(sx0, ry + 3, sx0 + 2, ry + ROW_H - 4, accent);
            } else if (h > 0.02f) {
                Gfx.fillRound(g, sx0, ry, sx1, ry + ROW_H - 1, 3, Gfx.alpha(0xFFFFFFFF, 0.06f * h));
            }
            icon(g, c.icon, sx0 + 7, ry + 2.5f, 0.75f);
            g.drawString(font, c.title, sx0 + 24, ry + 5, act ? TEXT : Gfx.mix(DIM, TEXT, h));
            String n = String.valueOf(StyleLibrary.count(c));
            g.drawString(font, n, sx1 - 6 - font.width(n), ry + 5, FAINT);
            final Category target = c;
            hits.add(new Hit(sx0, Math.max(ry, sy0), sx1, Math.min(ry + ROW_H, sy1),
                    () -> selectCategory(target), null));
        }
        g.disableScissor();
    }

    private void drawMain(GuiGraphics g, int mx, int my, int accent) {
        text(g, category.title, mx0, topY + 6, 1.5f, TEXT);
        g.drawString(font, StyleLibrary.count(category) + " styles", mx0, topY + 24, DIM);

        // Filter rechts: ALL / FAVORITES
        String favLabel = "\u2605 FAVORITES " + cfg.favorites.size();
        String allLabel = "ALL";
        int favX = mx1 - font.width(favLabel);
        int allX = favX - 12 - font.width(allLabel);
        int fy = topY + 8;
        g.drawString(font, allLabel, allX, fy, favoritesOnly ? DIM : TEXT);
        if (!favoritesOnly) g.fill(allX, fy + 10, allX + font.width(allLabel), fy + 11, accent);
        g.drawString(font, favLabel, favX, fy, favoritesOnly ? GOLD : DIM);
        if (favoritesOnly) g.fill(favX, fy + 10, favX + font.width(favLabel), fy + 11, GOLD);
        hits.add(new Hit(allX - 2, fy - 3, allX + font.width(allLabel) + 2, fy + 13, () -> {
            favoritesOnly = false;
            scrollTarget = 0;
        }, null));
        hits.add(new Hit(favX - 2, fy - 3, mx1 + 2, fy + 13, () -> {
            favoritesOnly = true;
            scrollTarget = 0;
        }, null));

        // Suchfeld
        int sbW = 96;
        int sbX = allX - 12 - sbW - 10;
        Gfx.roundBorder(g, sbX - 4, fy - 4, sbX + sbW + 4, fy + 14, 4, 0xFF24243A, 0xFF0E0E16);
        search.setPosition(sbX + 2, fy);
        search.setWidth(sbW - 2);

        g.fill(mx0, topY + 35, mx1, topY + 36, Gfx.alpha(0xFFFFFFFF, 0.06f));

        List<Block> blocks = filtered();
        int cols = Math.max(1, (gx1 - gx0 + GAP) / (CW + GAP));

        g.enableScissor(gx0, gy0, gx1, gy1);
        float y = gy0 - scroll;
        if (blocks.isEmpty()) {
            String msg = favoritesOnly ? "Noch keine Favoriten" : "Keine Designs gefunden";
            g.drawString(font, msg, gx0 + (gx1 - gx0 - font.width(msg)) / 2, gy0 + 30, DIM);
            y = gy0;
        }
        for (Block b : blocks) {
            g.drawString(font, b.section().name().toUpperCase(Locale.ROOT), gx0, Math.round(y) + 1,
                    Gfx.mix(DIM, accent, 0.45f));
            y += 14;
            int idx = 0;
            for (Style st : b.styles()) {
                int cx = gx0 + (idx % cols) * (CW + GAP);
                int cy = Math.round(y) + (idx / cols) * (CH + GAP);
                idx++;
                if (cy + CH + 4 < gy0 || cy - 4 > gy1) continue;
                drawCard(g, mx, my, accent, b.section(), st, cx, cy);
            }
            int rows = (b.styles().size() + cols - 1) / cols;
            y += rows * (CH + GAP) + 6;
        }
        contentHeight = y + scroll - gy0;
        if (StyleLibrary.count(category) == category.sections.size() && !favoritesOnly && query.isEmpty()) {
            String hint = "Importierte Packs erscheinen hier (Import folgt in Phase 4).";
            int hy = Math.round(y) + 4;
            if (hy < gy1) g.drawString(font, hint, gx0, hy, FAINT);
            contentHeight += 16;
        }
        g.disableScissor();

        float maxScroll = Math.max(0, contentHeight - (gy1 - gy0));
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        if (maxScroll > 0) {
            int trackH = gy1 - gy0;
            int barH = Math.max(16, Math.round(trackH * trackH / contentHeight));
            int barY = gy0 + Math.round((trackH - barH) * (scroll / maxScroll));
            Gfx.fillRound(g, gx1 + 3, barY, gx1 + 5, barY + barH, 1, Gfx.alpha(accent, 0.6f));
        }
    }

    private void drawCard(GuiGraphics g, int mx, int my, int accent, Section sec, Style st, int cx, int cy) {
        String fk = favKey(sec, st);
        boolean sel = cfg.selected(key(sec)).equals(st.id());
        boolean fav = cfg.favorites.contains(fk);
        boolean hov = in(mx, my, cx, cy, cx + CW, cy + CH) && my >= gy0 && my < gy1;
        float h = anim("card/" + fk, hov);
        int lift = Math.round(h * 2);
        int y0 = cy - lift;

        int fill = Gfx.mix(0xFF12121C, accent, 0.08f * h + (sel ? 0.10f : 0f));
        int border = sel ? accent : Gfx.mix(0xFF22223A, accent, 0.6f * h);
        Gfx.roundBorder(g, cx, y0, cx + CW, y0 + CH, 5, border, fill);
        g.fillGradient(cx + 2, y0 + 2, cx + CW - 2, y0 + CH - 24,
                Gfx.alpha(accent, 0.12f + 0.12f * h), 0x00000000);

        icon(g, sec.icon(), cx + (CW - 48) / 2f, y0 + 9, 3f);

        String name = font.plainSubstrByWidth(st.name(), CW - 8);
        g.drawString(font, name, cx + (CW - font.width(name)) / 2, y0 + CH - 14, sel ? accent : TEXT);

        if (sel) Gfx.fillRound(g, cx + 5, y0 + 5, cx + 9, y0 + 9, 2, GREEN);
        if (fav) {
            g.drawString(font, "\u2605", cx + CW - 12, y0 + 4, GOLD);
        } else if (hov) {
            g.drawString(font, "\u2605", cx + CW - 12, y0 + 4, FAINT);
        }

        if (hov) hoveredFavKey = fk;
        final String selKey = key(sec);
        final Zoom z = new Zoom(sec.icon(), st.name(), category.title + " \u00b7 " + sec.name());
        hits.add(new Hit(cx, Math.max(cy, gy0), cx + CW, Math.min(cy + CH, gy1), () -> {
            cfg.selection.put(selKey, st.id());
            cfg.save();
        }, () -> zoom = z));
    }

    private void drawPanel(GuiGraphics g, int mx, int my, int accent, int bg) {
        int px0 = mx1 + 6;
        int px1 = wx1 - 6;
        Gfx.roundBorder(g, px0, topY + 4, px1, botY - 4, 5,
                Gfx.mix(bg, accent, 0.16f), Gfx.mix(bg, 0xFFFFFFFF, 0.03f));
        int x = px0 + 8;
        int w = px1 - px0 - 16;
        int y = topY + 12;

        g.drawString(font, "THEMES", x, y, accent);
        g.fill(x, y + 11, x + font.width("THEMES"), y + 12, accent);
        y += 20;

        g.drawString(font, "PRESET", x, y, FAINT);
        y += 12;
        int cellW = w / 2;
        for (int i = 0; i < Theme.PRESETS.length; i++) {
            Theme.Preset p = Theme.PRESETS[i];
            int cx = x + (i % 2) * cellW;
            int cy = y + (i / 2) * 14;
            boolean on = (cfg.accent & 0xFFFFFF) == (p.color() & 0xFFFFFF);
            boolean hov = in(mx, my, cx, cy - 2, cx + cellW - 2, cy + 12);
            Gfx.fillRound(g, cx, cy - 2, cx + cellW - 3, cy + 12, 3,
                    Gfx.alpha(0xFFFFFFFF, on ? 0.10f : (hov ? 0.06f : 0.03f)));
            Gfx.fillRound(g, cx + 4, cy + 2, cx + 9, cy + 7, 2, p.color());
            g.drawString(font, p.name(), cx + 14, cy, on ? TEXT : DIM);
            final int color = p.color();
            hits.add(new Hit(cx, cy - 2, cx + cellW - 2, cy + 12, () -> {
                cfg.accent = color;
                cfg.save();
            }, null));
        }
        y += 3 * 14 + 6;

        g.drawString(font, "ACCENT", x, y, FAINT);
        y += 12;
        Gfx.roundBorder(g, x, y - 2, x + w, y + 12, 3, 0xFF24243A, 0xFF0E0E16);
        Gfx.fillRound(g, x + 4, y + 2, x + 9, y + 7, 2, accent);
        g.drawString(font, String.format("#%06X", accent & 0xFFFFFF), x + 14, y, TEXT);
        y += 22;

        g.drawString(font, "BACKGROUND", x, y, FAINT);
        y += 12;
        int bx = x;
        for (String mode : Theme.BACKGROUNDS) {
            String label = mode.substring(0, 1).toUpperCase(Locale.ROOT) + mode.substring(1);
            boolean on = cfg.background.equals(mode);
            int lw = font.width(label);
            g.drawString(font, label, bx, y, on ? TEXT : DIM);
            if (on) g.fill(bx, y + 10, bx + lw, y + 11, accent);
            final String target = mode;
            hits.add(new Hit(bx - 2, y - 3, bx + lw + 2, y + 13, () -> {
                cfg.background = target;
                cfg.save();
            }, null));
            bx += lw + 10;
        }
        y += 22;

        g.drawString(font, "OPACITY", x, y, FAINT);
        String pct = cfg.opacity + "%";
        g.drawString(font, pct, x + w - font.width(pct), y, TEXT);
        y += 13;
        sliderX0 = x;
        sliderX1 = x + w;
        sliderY0 = y - 3;
        sliderY1 = y + 9;
        Gfx.fillRound(g, x, y + 1, x + w, y + 4, 1, 0xFF22223A);
        float t = (cfg.opacity - 30) / 70f;
        int hx = x + Math.round(t * w);
        Gfx.fillRound(g, x, y + 1, Math.max(x + 2, hx), y + 4, 1, accent);
        Gfx.fillRound(g, hx - 3, y - 1, hx + 3, y + 7, 3, accent);
        y += 22;

        boolean hov = in(mx, my, x, y, x + 46, y + 14);
        Gfx.roundBorder(g, x, y, x + 46, y + 14, 3, hov ? accent : 0xFF24243A, 0xFF0E0E16);
        g.drawString(font, "RESET", x + 8, y + 3, hov ? TEXT : DIM);
        hits.add(new Hit(x, y, x + 46, y + 14, cfg::resetTheme, null));
    }

    private void drawFooter(GuiGraphics g, int mx, int my, int accent) {
        int y = botY;
        g.fill(wx0 + 6, y, wx1 - 6, y + 1, Gfx.alpha(0xFFFFFFFF, 0.06f));
        int by = y + 5;
        boolean hov = in(mx, my, wx0 + 10, by, wx0 + 56, by + 13);
        Gfx.roundBorder(g, wx0 + 10, by, wx0 + 56, by + 13, 3, hov ? accent : 0xFF24243A, 0xFF0E0E16);
        g.drawString(font, "RESET", wx0 + 18, by + 3, hov ? TEXT : DIM);
        hits.add(new Hit(wx0 + 10, by, wx0 + 56, by + 13, () -> {
            cfg.selection.clear();
            cfg.save();
        }, null));
        if (hov) {
            tooltip = "Alle Auswahlen auf Vanilla";
            tipX = mx;
            tipY = my - 28;
        }

        String right = "OPEN: RIGHT SHIFT";
        int rx = wx1 - 12 - font.width(right);
        g.drawString(font, right, rx, by + 3, FAINT);

        String hint = "LEFT-CLICK SELECT \u00b7 RIGHT-CLICK ZOOM \u00b7 F FAVORITE \u00b7 / SEARCH";
        int hw = font.width(hint);
        int hx = wx0 + (wx1 - wx0 - hw) / 2;
        if (hx > wx0 + 66 && hx + hw < rx - 8) {
            g.drawString(font, hint, hx, by + 3, FAINT);
        }
    }

    private void drawZoom(GuiGraphics g, int accent) {
        g.fill(0, 0, width, height, 0xCC000000);
        int w = 170;
        int h = 190;
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        Gfx.roundBorder(g, x, y, x + w, y + h, 6, accent, 0xFF10101A);
        icon(g, zoom.icon(), x + (w - 128) / 2f, y + 14, 8f);
        g.drawString(font, zoom.title(), x + (w - font.width(zoom.title())) / 2, y + h - 38, TEXT);
        g.drawString(font, zoom.subtitle(), x + (w - font.width(zoom.subtitle())) / 2, y + h - 26, DIM);
        String close = "Klicken zum Schliessen";
        g.drawString(font, close, x + (w - font.width(close)) / 2, y + h - 13, FAINT);
    }

    // -------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        int btn = event.button();

        if (zoom != null) {
            zoom = null;
            return true;
        }
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        search.setFocused(false);

        if (panelW > 0 && btn == 0 && in(mx, my, sliderX0 - 4, sliderY0, sliderX1 + 4, sliderY1)) {
            draggingOpacity = true;
            updateOpacity(mx);
            return true;
        }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (!hit.contains(mx, my)) continue;
            if (btn == 0 && hit.left() != null) {
                hit.left().run();
                return true;
            }
            if (btn == 1 && hit.right() != null) {
                hit.right().run();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (draggingOpacity) {
            updateOpacity(event.x());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (draggingOpacity) {
            draggingOpacity = false;
            cfg.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (in(mx, my, sx0, sy0, sx1, sy1)) {
            sideScrollTarget -= (float) vertical * 18f;
            return true;
        }
        if (in(mx, my, gx0, gy0, gx1 + 8, gy1)) {
            scrollTarget -= (float) vertical * 28f;
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (zoom != null && key == InputConstants.KEY_ESCAPE) {
            zoom = null;
            return true;
        }
        if (search.isFocused()) {
            return super.keyPressed(event);
        }
        if (key == InputConstants.KEY_F && hoveredFavKey != null) {
            toggleFavorite(hoveredFavKey);
            return true;
        }
        if (key == InputConstants.KEY_RSHIFT && ticks > 10) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!search.isFocused() && event.codepoint() == '/') {
            search.setFocused(true);
            setFocused(search);
            return true; // das '/'-Zeichen selbst wird verschluckt
        }
        return super.charTyped(event);
    }
}
