package com.pvppackmanager.data;

import java.util.List;

/**
 * Liefert die Designs je Kategorie und Bereich.
 * Phase 3: nur Vanilla. Importierte Packs werden in Phase 4 hier eingehaengt.
 */
public final class StyleLibrary {
    public static final Style VANILLA = new Style("vanilla", "Vanilla");

    private StyleLibrary() {}

    public static List<Style> styles(Category category, Section section) {
        return List.of(VANILLA);
    }

    public static int count(Category category) {
        int n = 0;
        for (Section s : category.sections) {
            n += styles(category, s).size();
        }
        return n;
    }
}
